import unittest
# Test the standalone scoring logic mirrored by the web app via endpoint-level assumptions.
# Importing app.py is safe and initializes the local SQLite database.
from app import assess

class RiskTests(unittest.TestCase):
    def test_low(self):
        self.assertEqual(assess({"rain_24h":2,"rain_3h":0,"forecast_24h":1})["risk_level"],"Low")
    def test_very_high(self):
        r=assess({"rain_24h":160,"rain_3h":55,"forecast_24h":110})
        self.assertEqual(r["risk_level"],"Very High")
        self.assertEqual(r["score"],100)
    def test_missing_values(self):
        r=assess({})
        self.assertEqual(len(r["missing_inputs"]),3)
    def test_negative_values_not_used(self):
        r=assess({"rain_24h":-2,"rain_3h":-1,"forecast_24h":-5})
        self.assertEqual(r["score"],0)

if __name__=="__main__": unittest.main()
